from django.contrib import admin
from assignmentApp.models import Passengers
# Register your models here.

class passengersUI(admin.ModelAdmin):
    list_display = ['firstName','lastName','email','rewardPoints']

admin.site.register(Passengers,passengersUI)
