from assignmentApp.models import Passengers
from django.shortcuts import render
# Create your views here.

def displayPassengers(request):
    emp = Passengers.objects.all()
    emp_dict = {"Passengers": emp}
    return render(request,'assignmentApp/assignment.html',emp_dict)
