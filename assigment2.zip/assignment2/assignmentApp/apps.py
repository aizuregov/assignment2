from django.apps import AppConfig


class AssignmentappConfig(AppConfig):
    name = 'assignmentApp'
